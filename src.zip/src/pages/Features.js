export const Features = () => {
    return <div>Features</div>
}