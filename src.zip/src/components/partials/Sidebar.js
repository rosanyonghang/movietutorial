import {Logo} from "../common/Logo";

export const Sidebar = () => {
    return <div className={"side-bar-section"}>
        <Logo/>
        <div className="side-bar-items">
            <div className="side-bar-item"></div>
            <div className="side-bar-item">Home</div>
            <div className="side-bar-item">About</div>
            <div className="side-bar-item">Services</div>
            <div className="side-bar-item">Features</div>
            <div className="side-bar-item">Contact</div>
        </div>
    </div>
}