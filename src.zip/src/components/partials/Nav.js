export const Nav = () => {
    return <nav>
        <div className="avatar">
            <div className="name">User</div>
        </div>
    </nav>
}