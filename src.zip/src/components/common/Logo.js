export const Logo = () => {
    return <div className={"logo"}>Logo</div>
}